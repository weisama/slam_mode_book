#include "stm32f10x.h"
#include "app.h"
#include "example.h"
/* Select EXAMPLE_DRONE explicitly to start a drone mission. */
#define SELECTED_EXAMPLE EXAMPLE_CAR
void USART1_Init(uint32_t baud)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE);

    // TX PA9 复用推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // RX PA10 上拉输入
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // USART 初始化
    USART_InitStructure.USART_BaudRate = baud;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);

    // 使能接收中断
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    // NVIC 配置
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    // 使能串口
    USART_Cmd(USART1, ENABLE);
}




static volatile uint32_t ticks;
uint32_t board_now_ms(void) { return ticks; }
extern void app_discard_rx(void);
void board_rx_reset(void) { uint32_t mask = __get_PRIMASK(); __disable_irq(); app_discard_rx(); if (!mask) __enable_irq(); }
int board_send_frame(const uint8_t frame[15]) {
    unsigned i;
    for (i = 0; i < 15; ++i) { while (!(USART1->SR & USART_SR_TXE)) {} USART1->DR = frame[i]; }
    return 1;
}

void SysTick_Handler(void) { ++ticks; }
void USART1_IRQHandler(void) {
    uint32_t status = USART1->SR;
    if (status & (USART_SR_RXNE | USART_SR_ORE | USART_SR_FE | USART_SR_NE)) {
        uint8_t byte = (uint8_t)USART1->DR;
        if (status & (USART_SR_ORE | USART_SR_FE | USART_SR_NE)) app_rx_error();
    else if (status & USART_SR_RXNE) app_rx_interrupt(byte);
    }
}
int main(void) {
    SystemCoreClockUpdate(); SysTick_Config(SystemCoreClock / 1000u);
    app_init(); example_start(SELECTED_EXAMPLE); USART1_Init(115200);
    for (;;) app_poll(ticks);
}
