﻿#ifndef STM32_V3_PROTOCOL_H
#define STM32_V3_PROTOCOL_H
#include <stddef.h>
#include <stdint.h>
#define PROTOCOL_FRAME_SIZE 15u
#define PROTOCOL_PARAM_COUNT 22u

/* 接收回调中的 frame 仅在回调期间有效；需要保存时应复制。 */
typedef struct {
    uint8_t bytes[15];
} protocol_frame;
/* 0x05 状态帧的五个原始字节，由接收帧更新。 */
typedef struct {
    uint8_t flight; /* 0 未连接，1 未解锁，2 已解锁在地，3 空中悬停，4 执行航点。 */
    uint8_t relocalization; /* 0 进行中，1 成功，2 失败，3 未响应。 */
    uint8_t planning; /* 0 进行中，1 成功，2 失败，3 未响应。 */
    uint8_t cpu; /* CPU 占用百分比；0xff 表示未知。 */
    uint8_t memory; /* 内存占用百分比；0xff 表示未知。 */
} protocol_status;
typedef void (*protocol_receive_fn)(void *user, const protocol_frame *frame);
/* buffer/length 保存未完成的帧；receive/user 为回调及其上下文。 */
typedef struct {
    uint8_t buffer[15];
    uint8_t length;
    protocol_receive_fn receive;
    void *user;
} protocol_parser;
/* 参数 ID 顺序同时决定请求结果数组及掩码的位序。 */
extern const uint8_t protocol_param_ids[PROTOCOL_PARAM_COUNT];
/* 编码 6 个有符号值；id 指定帧类型。 */
void protocol_encode_data(uint8_t out[15], uint8_t id, const int16_t values[6]);
/* 解码类型 1 至 4 的帧，成功返回 1。 */
int protocol_decode_data(const uint8_t frame[15], int16_t values[6]);
/* 解码状态帧，类型或格式不符时返回 0。 */
int protocol_decode_status(const uint8_t frame[15], protocol_status *status);
/* 编码支持的命令；未知命令返回 0。 */
int protocol_encode_command(uint8_t out[15], uint8_t command);
/* 编码参数写入帧；未知 ID 返回 0。 */
int protocol_encode_parameter(uint8_t out[15], uint8_t id, int16_t value);
/* 初始化解析器，并设置完整帧回调和上下文。 */
void protocol_parser_init(protocol_parser *parser, protocol_receive_fn receive, void *user);
/* 接收任意长度字节流，拼接完整帧并调用接收回调。 */
void protocol_parser_feed(protocol_parser *parser, const uint8_t *bytes, size_t length);

/* 请求尚未开始、等待响应、已完成或超时。 */
typedef enum {
    PROTOCOL_IDLE,
    PROTOCOL_WAITING,
    PROTOCOL_COMPLETE,
    PROTOCOL_TIMEOUT
} protocol_result;
/* received_mask 的位序与 protocol_param_ids 一致，用于追踪已收到的参数。 */
typedef struct {
    /* command 为请求命令；echo_received 标记是否收到匹配回显。 */
    uint8_t command, echo_received;
    /* 开始时刻、超时毫秒数和已收到参数的掩码。 */
    uint32_t started_ms, timeout_ms, received_mask;
    /* 接收的参数值按 protocol_param_ids 顺序存放；只在对应掩码位为 1 时有效。
     * 超时保留已收部分；开始下一次请求时清空。 */
    int16_t parameters[PROTOCOL_PARAM_COUNT];
    /* 当前请求状态。 */
    protocol_result result;
} protocol_request;
/* 开始跟踪请求，不发送帧；时间使用同一个毫秒时钟。 */
int protocol_request_start(protocol_request *request, uint8_t command, uint32_t now_ms,
                           uint32_t timeout_ms);
/* 根据收到的帧更新请求，收齐响应后标记完成。 */
void protocol_request_accept(protocol_request *request, const protocol_frame *frame);
/* 检查超时并返回当前请求状态。 */
protocol_result protocol_request_poll(protocol_request *request, uint32_t now_ms);
#endif
