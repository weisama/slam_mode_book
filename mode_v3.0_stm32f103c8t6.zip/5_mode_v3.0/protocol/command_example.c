#include "command_example.h"
#include <string.h>

/* 需要接收参数集合的两个命令。 */
enum { READ_PARAMETERS = 0x03, SAVE_PARAMETERS = 0x04 };

/* 校验命令回显并将帧交给请求跟踪器。 */
static void on_frame(void *user, const protocol_frame *frame) {
    command_example *example = (command_example *)user;
    uint8_t expected[15];
    /* 命令回显必须与发送帧逐字节一致，参数帧交给请求跟踪器处理。 */
    if (frame->bytes[1] == 0 && protocol_encode_command(expected, example->request.command) &&
        memcmp(frame->bytes, expected, sizeof(expected)) != 0)
        return;
    protocol_request_accept(&example->request, frame);
}

void command_example_init(command_example *example, example_transmit_fn transmit, void *user) {
    memset(example, 0, sizeof(*example));
    example->transmit = transmit;
    example->user = user;
    protocol_parser_init(&example->parser, on_frame, example);
}

int command_example_start(command_example *example, uint8_t command, uint32_t now_ms,
                          uint32_t timeout_ms) {
    uint8_t frame[15];
    if (example->request.result == PROTOCOL_WAITING || !example->transmit ||
        !protocol_encode_command(frame, command) ||
        !protocol_request_start(&example->request, command, now_ms, timeout_ms))
        return 0;
    if (!example->transmit(example->user, frame)) {
        example->request.result = PROTOCOL_IDLE;
        return 0;
    }
    return 1;
}

int command_example_write_parameter(command_example *example, uint8_t id, int16_t value) {
    uint8_t frame[15];
    if (example->request.result == PROTOCOL_WAITING || !example->transmit ||
        !protocol_encode_parameter(frame, id, value))
        return 0;
    return example->transmit(example->user, frame);
}

void command_example_receive(command_example *example, const uint8_t *bytes, size_t length,
                             uint32_t now_ms) {
    /* 先检查超时，避免把截止时刻之后的帧算作本次请求的响应。 */
    protocol_request_poll(&example->request, now_ms);
    protocol_parser_feed(&example->parser, bytes, length);
}

example_result command_example_poll(command_example *example, uint32_t now_ms) {
    protocol_result result = protocol_request_poll(&example->request, now_ms);
    if (result == PROTOCOL_WAITING)
        return EXAMPLE_WAITING;
    if (result == PROTOCOL_COMPLETE) {
        return example->request.command == READ_PARAMETERS ||
                       example->request.command == SAVE_PARAMETERS
                   ? EXAMPLE_PARAMETERS_RECEIVED
                   : EXAMPLE_ECHO_RECEIVED;
    }
    if (result == PROTOCOL_TIMEOUT) {
        return example->request.received_mask || example->request.echo_received
                   ? EXAMPLE_INCOMPLETE
                   : EXAMPLE_NO_RESPONSE;
    }
    return EXAMPLE_IDLE;
}
