﻿#include "protocol.h"
#include <string.h>
const uint8_t protocol_param_ids[PROTOCOL_PARAM_COUNT] = {
    0,    1,    2,    3,    4,    5,    6,    0x11, 0x12, 0x13, 0x14,
    0x15, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x99};
/* 查找参数 ID 在结果数组中的位置；找不到返回 -1。 */
static int param_index(uint8_t id) {
    unsigned i;
    for (i = 0; i < PROTOCOL_PARAM_COUNT; ++i)
        if (protocol_param_ids[i] == id)
            return (int)i;
    return -1;
}
/* 支持跟踪的命令及全部参数收齐时的掩码。 */
enum { CMD_TEST = 1, CMD_SAVE_MAP = 2, CMD_READ_PARAMS = 3, CMD_SAVE_PARAMS = 4, CMD_RESTART = 6 };
#define ALL_PARAMS_MASK (((uint32_t)1u << PROTOCOL_PARAM_COUNT) - 1u)
/* 检查命令是否属于本实现支持的集合。 */
static int valid_command(uint8_t c) {
    return c == CMD_TEST || c == CMD_SAVE_MAP || c == CMD_READ_PARAMS || c == CMD_SAVE_PARAMS ||
           c == CMD_RESTART;
}
/* 帧固定为 15 字节：帧头、类型、12 字节数据和帧尾；16 位数按高字节在前传输。 */
static int valid_frame(const uint8_t *f) {
    return f[0] == 0xaa && f[14] == 0x0a;
}
/* 从高字节在前的两个字节还原有符号 16 位值。 */
static int16_t decode16(const uint8_t *p) {
    uint16_t u = (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
    return u <= 32767u ? (int16_t)u : (int16_t)((int32_t)u - 65536);
}
/* 将有符号值按高字节在前写入两个字节。 */
static void encode16(uint8_t *p, int16_t v) {
    uint16_t u = (uint16_t)v;
    p[0] = (uint8_t)(u >> 8);
    p[1] = (uint8_t)u;
}
/* 清空帧数据并设置帧头、类型和帧尾。 */
static void init_frame(uint8_t *f, uint8_t id) {
    memset(f, 0, 15);
    f[0] = 0xaa;
    f[1] = id;
    f[14] = 0x0a;
}
void protocol_encode_data(uint8_t out[15], uint8_t id, const int16_t values[6]) {
    unsigned i;
    init_frame(out, id);
    for (i = 0; i < 6; ++i)
        encode16(out + 2 + 2 * i, values[i]);
}
int protocol_decode_data(const uint8_t f[15], int16_t values[6]) {
    unsigned i;
    if (!valid_frame(f) || f[1] < 1 || f[1] > 4)
        return 0;
    for (i = 0; i < 6; ++i)
        values[i] = decode16(f + 2 + 2 * i);
    return 1;
}
int protocol_decode_status(const uint8_t f[15], protocol_status *s) {
    if (!valid_frame(f) || f[1] != 5)
        return 0;
    s->flight = f[2];
    s->relocalization = f[3];
    s->planning = f[4];
    s->cpu = f[5];
    s->memory = f[6];
    return 1;
}
int protocol_encode_command(uint8_t out[15], uint8_t c) {
    if (!valid_command(c))
        return 0;
    init_frame(out, 0);
    out[2] = c;
    return 1;
}
int protocol_encode_parameter(uint8_t out[15], uint8_t id, int16_t value) {
    if (param_index(id) < 0)
        return 0;
    init_frame(out, 0x10);
    out[2] = id;
    encode16(out + 3, value);
    return 1;
}
void protocol_parser_init(protocol_parser *p, protocol_receive_fn receive, void *user) {
    p->length = 0;
    p->receive = receive;
    p->user = user;
}
void protocol_parser_feed(protocol_parser *p, const uint8_t *bytes, size_t n) {
    size_t i;
    for (i = 0; i < n; ++i) {
        if (p->length == 0 && bytes[i] != 0xaa)
            continue;
        p->buffer[p->length++] = bytes[i];
        if (p->length == 15) {
            if (p->buffer[14] == 0x0a) {
                protocol_frame frame;
                memcpy(frame.bytes, p->buffer, 15);
                p->length = 0;
                if (p->receive)
                    p->receive(p->user, &frame);
            } else {
                /* 帧尾错误时保留后续可能的帧头，继续从流中寻找同步位置。 */
                unsigned j;
                for (j = 1; j < 15 && p->buffer[j] != 0xaa; ++j) {
                }
                p->length = (uint8_t)(15 - j);
                memmove(p->buffer, p->buffer + j, p->length);
            }
        }
    }
}
int protocol_request_start(protocol_request *r, uint8_t command, uint32_t now, uint32_t timeout) {
    if (!valid_command(command) || timeout == 0)
        return 0;
    memset(r, 0, sizeof(*r));
    r->command = command;
    r->started_ms = now;
    r->timeout_ms = timeout;
    r->result = PROTOCOL_WAITING;
    return 1;
}
void protocol_request_accept(protocol_request *r, const protocol_frame *f) {
    int index;
    if (r->result != PROTOCOL_WAITING || !valid_frame(f->bytes))
        return;
    /* 读取参数须收齐全部参数；保存参数还须收到对应命令回显。 */
    if (f->bytes[1] == 0x10 && (r->command == CMD_READ_PARAMS || r->command == CMD_SAVE_PARAMS)) {
        index = param_index(f->bytes[2]);
        if (index >= 0) {
            r->parameters[index] = decode16(f->bytes + 3);
            r->received_mask |= (uint32_t)1u << index;
        }
    } else if (f->bytes[1] == 0 && f->bytes[2] == r->command && r->command != CMD_READ_PARAMS)
        r->echo_received = 1;
    if ((r->command == CMD_READ_PARAMS && r->received_mask == ALL_PARAMS_MASK) ||
        (r->command == CMD_SAVE_PARAMS && r->received_mask == ALL_PARAMS_MASK &&
         r->echo_received) ||
        ((r->command == CMD_TEST || r->command == CMD_SAVE_MAP || r->command == CMD_RESTART) &&
         r->echo_received))
        r->result = PROTOCOL_COMPLETE;
}
protocol_result protocol_request_poll(protocol_request *r, uint32_t now) {
    if (r->result == PROTOCOL_WAITING && (uint32_t)(now - r->started_ms) >= r->timeout_ms)
        r->result = PROTOCOL_TIMEOUT;
    return r->result;
}
