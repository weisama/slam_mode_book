﻿#ifndef STM32_V3_NAVIGATION_H
#define STM32_V3_NAVIGATION_H
#include "protocol.h"

/* 等待起飞、发送、等待回显、等待到达、暂停、完成和失败。 */
typedef enum {
    NAV_WAIT_TAKEOFF,
    NAV_SEND,
    NAV_WAIT_ECHO,
    NAV_WAIT_ARRIVAL,
    NAV_PAUSED,
    NAV_COMPLETE,
    NAV_FAILED
} navigation_state;
/* 距离单位为厘米，时间单位为毫秒。目标数组须在导航期间保持有效。 */
typedef struct {
    int16_t takeoff_cm; /* 起飞高度阈值。 */
    int16_t tolerance_cm; /* 水平各轴到达容差。 */
    uint32_t hold_ms; /* 条件需要连续保持的时间。 */
    uint32_t pose_timeout_ms; /* 位姿有效期。 */
    uint32_t status_timeout_ms; /* 状态有效期。 */
    uint32_t echo_timeout_ms; /* 目标回显超时。 */
    uint32_t goal_interval_ms; /* 不同目标的最小发送间隔。 */
    uint8_t max_sends; /* 单目标最大发送次数，含首次。 */
    uint8_t require_height_confirmation; /* 是否要求人工高度确认。 */
} navigation_config;
/* 同步发送帧的回调及其调用方上下文。 */
typedef void (*navigation_send_fn)(void *user, const uint8_t frame[15]);
typedef struct {
    navigation_config config; /* 配置副本。 */
    const int16_t (*goals)[6]; /* 调用方持有的航点数组。 */
    size_t goal_count; /* 航点数量。 */
    size_t goal_index; /* 当前航点下标。 */
    navigation_send_fn send; /* 发送回调。 */
    void *user; /* 发送回调上下文。 */
    navigation_state state; /* 当前状态。 */
    navigation_state resume_state; /* 暂停后恢复的状态。 */
    int16_t pose[6]; /* 最新位姿。 */
    uint8_t flight; /* 最新飞控状态。 */
    uint8_t have_pose; /* 是否收到位姿。 */
    uint8_t have_status; /* 是否收到状态。 */
    uint8_t height_confirmed; /* 是否已人工确认高度。 */
    uint8_t holding; /* 是否正在计时连续满足的条件。 */
    uint8_t sends; /* 当前目标已发送次数。 */
    uint8_t have_sent; /* 是否曾发送目标。 */
    uint8_t goal_frame[15]; /* 待匹配回显的目标帧。 */
    uint32_t pose_ms; /* 最新位姿接收时刻。 */
    uint32_t status_ms; /* 最新状态接收时刻。 */
    uint32_t hold_ms; /* 连续满足条件的开始时刻。 */
    uint32_t sent_ms; /* 当前目标最近发送时刻。 */
    uint32_t last_goal_ms; /* 最近一次目标发送时刻。 */
} navigation;
/* 返回默认导航配置，时间单位为毫秒。 */
navigation_config navigation_defaults(void);
/* 初始化状态机；参数无效时返回 0。目标数组在导航期间须保持有效。 */
int navigation_init(navigation *n, const navigation_config *config, const int16_t (*goals)[6],
                    size_t count, navigation_send_fn send, void *user);
/* 设置或撤销人工高度确认；撤销时按配置暂停导航。 */
void navigation_confirm_height(navigation *n, int valid);
/* 根据帧到达时刻更新位姿、状态或目标回显。 */
void navigation_accept(navigation *n, const protocol_frame *frame, uint32_t now_ms);
/* 推进状态机，必要时通过回调发送或重发目标。 */
void navigation_poll(navigation *n, uint32_t now_ms);
#endif
