# STM32 3.0 serial protocol core

Hardware-independent C99 code shared by HAL and standard-peripheral-library projects. Protocol reference: [v3.0 serial protocol](../docs/通讯协议.md). Both endpoints must use the same protocol version: frames contain no version byte.

Add `protocol.c` and `protocol.h` to the project. Initialize a `protocol_parser`, feed received UART bytes in order, and handle each complete `protocol_frame` in the callback. `protocol_decode_data` returns six signed big-endian values for IDs 01–04; positions are cm in `base_init_map`, angles degrees, velocities cm/s and yaw rate degrees/s. ID 02 echo confirms receipt only, not planner acceptance or arrival; the module publishes different goals at most once per second. `protocol_decode_status` exposes the five raw bytes: relocalization/planning 3 means no response, and CPU/memory FF means unknown, not 255%. The protocol document still marks the resource fields as pending review.

```c
static protocol_parser parser;
static protocol_request request;
static void received(void *user, const protocol_frame *frame) {
    (void)user;
    protocol_request_accept(&request, frame);
    /* Decode or copy the frame here. */
}
/* At startup: protocol_parser_init(&parser, received, 0); */
/* In the main loop: protocol_parser_feed(&parser, bytes, length); */
/* A user-triggered command, after ensuring the UART can transmit 15 bytes: */
/* protocol_request_start(&request, 3, now_ms, 2000); */
/* protocol_encode_command(tx, 3); uart_send(tx, 15); */
/* Later: protocol_request_poll(&request, now_ms); */
```

Commands 01 test, 02 save map, 03 read parameters, 04 save parameters and 06 restart are supported; 05 map download is not. Read waits for all 22 distinct IDs, save waits for all 22 and the command echo. The received mask and parameter array retain partial results on timeout. Save-map echo means success; no echo may mean failure or communication loss. Restart echo only confirms receipt before execution, not successful restart. Parameter writes use `protocol_encode_parameter` and have no response; ID 23 is takeoff height and 24 robot radius. Operations are never sent automatically. The caller must choose a timeout suitable for the operation, poll before accepting late responses, and serialize requests; the wire format has no transaction ID and a late response cannot be distinguished from a new request. Unsigned millisecond subtraction supports clock wrap provided polling occurs within one clock cycle.

## Manual command and parameter example

Add `command_example.c` and `command_example.h` alongside the protocol core. Initialize once, feed incoming bytes and poll in the same execution context. The transmit callback must synchronously send or copy all 15 bytes before returning nonzero; return zero if it could not do so. Initialization never sends anything. Replace `uart_send_copy` and `millis` with the board's UART and monotonic millisecond clock:

```c
static command_example commands;
static int send_frame(void *user, const uint8_t frame[15]) {
    (void)user;
    return uart_send_copy(frame, 15); /* nonzero only when accepted */
}
/* startup: command_example_init(&commands, send_frame, 0); */
/* each received chunk: command_example_receive(&commands, bytes, length, millis()); */
/* in main loop: result = command_example_poll(&commands, millis()); */

/* Each line below is a separate user action, after the previous request ends. */
command_example_start(&commands, 0x01, millis(), 2000); /* test communication */
command_example_start(&commands, 0x02, millis(), 30000); /* save map */
command_example_start(&commands, 0x03, millis(), 2000); /* read parameters */
command_example_write_parameter(&commands, 0x23, 100); /* takeoff height, cm */
command_example_start(&commands, 0x04, millis(), 5000); /* save and read back */
command_example_start(&commands, 0x06, millis(), 2000); /* restart algorithms */
```

Check each call's return value: zero means invalid input, another request is waiting, or transmission failed; no command is pending after a failed transmission. The timeouts above are examples, not guarantees. `EXAMPLE_WAITING` means keep receiving; `EXAMPLE_NO_RESPONSE` means nothing relevant arrived before the deadline; `EXAMPLE_INCOMPLETE` means some parameters or the save echo arrived but the required response was incomplete. `EXAMPLE_PARAMETERS_RECEIVED` means all 22 distinct IDs were received, and for save also the echo. `EXAMPLE_ECHO_RECEIVED` means the command echo arrived. For map saving this indicates success; absent echo can mean failure, rejection, or communication loss. For restart it indicates receipt only: verify the module stack separately to establish whether restart succeeded. A parameter write has no echo and does not start a request; its return value confirms only local transmission. Read back to verify a change, then explicitly save if persistence is wanted.

Parameters arrive in table order, but are indexed by ID so missing or duplicate frames cannot masquerade as a complete set. For each index `i` from 0 to 21, `protocol_param_ids[i]` is the ID, `commands.request.parameters[i]` its value, and bit `i` of `commands.request.received_mask` says whether it arrived. Partial values and the echo flag remain available after timeout until the next request. Refer to the [current parameter table](../docs/通讯协议.md#参数id定义表) for every ID, range and default; in particular `0x23` is takeoff height (0–1000 cm, default 100) and `0x24` is robot radius (0–1000 cm, default 10). The encoder checks IDs, not value ranges: the user must select valid values for the module and scenario. No serial `00 05` command is supported.

Run the example host test with `gcc -std=c99 -Wall -Wextra -Werror -I. protocol.c command_example.c tests/test_command_example.c -o command_test` and run `./command_test`.

The parser owns 15 bytes and calls the receiver synchronously; it has no queue or overflow. Feed and callbacks must run in one context, or the caller must protect the parser and request from concurrent access. If an interrupt queues UART bytes, size that external queue for the maximum service delay; on overflow discard buffered input and reinitialize the parser before resuming. Never call `protocol_parser_feed` recursively from its callback. Copy callback frames if retaining them. The parser waits for exactly 15 bytes, never treats AA or 0A in payload as delimiters, and after a bad tail searches the candidate for the next AA. With no checksum or escaping, arbitrary corruption can form a plausible false frame; reliable resynchronization for every possible damaged stream is impossible.

Host test (GCC):

```
gcc -std=c99 -Wall -Wextra -Werror -I. protocol.c tests/test_protocol.c -o protocol_test
./protocol_test
```

For a goal, encode ID 02 with six values (normally roll and pitch zero), send the 15 bytes, then compare the entire returned frame with the transmitted frame. Pace **different** goals at least 1000 ms apart; receipt of an echo does not reset the module's publication limit or guarantee publication. The parser does not schedule transmissions. For a parameter write, call `protocol_encode_parameter(tx, 0x23, 100)` and transmit once; do not wait for an acknowledgment. For commands, choose 01, 02, 03, 04 or 06 in the example above and inspect `protocol_request_poll`: `PROTOCOL_WAITING` means keep receiving, `PROTOCOL_COMPLETE` means the documented response arrived, and `PROTOCOL_TIMEOUT` means the response was incomplete or absent. Inspect `received_mask` and `parameters` for partial reads or saves. In particular, do not interpret restart completion as proof of execution.

The mixed-stream host test supplies one second's frame counts (100 each of 03 and 04, 10 of 01 and one of 05), or 3165 bytes, within the nominal 11520 bytes/s available at 115200 8N1. It does not simulate UART timing or verify module-side goal throttling; those require integration with the actual sender/module.

## Drone navigation state machine

Add `navigation.c` and `navigation.h` beside the protocol core. The same code is used for 2D and 3D lidar. Call `navigation_init` only when the user selects the drone example, with a persistent array of six-value ID 02 goals and a transmit callback that promptly queues all 15 bytes. The callback must not block reception. Feed every received frame to `navigation_accept` with its monotonic millisecond timestamp; call `navigation_poll` frequently in the same execution context, including immediately after processing incoming frames. Protect shared data if UART interrupts and the main loop use different contexts. The parser and navigation do not allocate or perform I/O. Goal storage must remain unchanged for the mission.

Defaults are Z > 50 cm and X/Y each within 20 cm for 1000 ms, pose freshness 500 ms, flight-status freshness 2000 ms, echo timeout 300 ms, five transmissions, and at least 1000 ms between the last transmission of one goal and the first of the next. These are configurable via `navigation_config`, except that the echo timeout must remain 300 ms, the send limit cannot exceed five, and the goal interval cannot be shorter than 1000 ms; choose a pose timeout appropriate for the stream. All times use unsigned millisecond subtraction, so poll and receive at least once per clock cycle. Both lidar cases require fresh flight status 3 or 4 and fresh pose for every transition and transmission. Intermediate samples outside the threshold reset the hold; a missing stream also interrupts it. A matching byte-for-byte echo only confirms frame receipt, not publication, planner acceptance, or arrival. Different goals are paced because pose_send echoes before publishing and limits publication to one goal per second; even a match is not proof of planning success.

On missing or disallowed status, stale pose, or revoked height confirmation, `NAV_PAUSED` retains the current waypoint and clears the hold timer. Once both streams are fresh and allowed, the previous stage resumes; an interrupted echo wait retries the same goal after the original 300 ms deadline and retains its transmission count. Late echoes while paused or after the 300 ms deadline are ignored. After five unanswered sends the machine enters `NAV_FAILED` and waits for user intervention; reinitialization starts a new mission. It never sends unlock, takeoff, or landing commands. The module, flight controller, and external operator handle those actions.

The unified STM32 example does not branch on lidar type or require parameter reads at startup. Drone mode leaves `require_height_confirmation` disabled. Applications that need an explicit operator gate may still enable it and call `navigation_confirm_height(&nav, 1)` after independently verifying altitude; revoke confirmation when that assurance is lost. This optional gate is independent of lidar type. In 2D the module's pose Z comes from flight-controller position and starts at zero; a numeric Z value or fresh serial pose alone cannot prove flight-controller altitude freshness. The module still replaces the goal Z with `takeoff_height`; STM32 unification does not change this module behavior. In 3D pose Z comes from TF and the module uses the waypoint Z. 2D navigation supports planning mode 0; actual drone control and planning availability require module and flight validation.

Run the host navigation test alongside `tests/test_protocol.c`, linking each test separately with `protocol.c` and linking `navigation.c` for the navigation test. Hardware integration and flight validation are separate from these host tests.

Typical integration (supply a nonblocking UART queue and a monotonic clock):

```c
static navigation nav;
static protocol_parser parser;
static const int16_t waypoints[][6] = {{100, 200, 100, 0, 0, 0}, {300, 400, 100, 0, 0, 0}};
static void send_goal(void *user, const uint8_t frame[15]) {
    (void)user; uart_queue_frame(frame, 15); /* queue must have capacity */
}
static void on_frame(void *user, const protocol_frame *frame) {
    navigation_accept((navigation *)user, frame, milliseconds());
}
/* After the user selects the drone example: */
/* navigation_config config = navigation_defaults(); */
/* config.require_height_confirmation = 1; // optional operator height gate */
/* navigation_init(&nav, &config, waypoints, 2, send_goal, 0); */
/* protocol_parser_init(&parser, on_frame, &nav); */
/* If the optional gate is enabled, after checking altitude: navigation_confirm_height(&nav, 1); */
/* Main loop: feed queued UART bytes to parser, then navigation_poll(&nav, milliseconds()); */
```
