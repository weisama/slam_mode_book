#include "navigation.h"
#include <string.h>

navigation_config navigation_defaults(void) {
    navigation_config c = {50, 20, 1000, 500, 2000, 300, 1000, 5, 0};
    return c;
}
int navigation_init(navigation *n, const navigation_config *c, const int16_t (*goals)[6],
                    size_t count, navigation_send_fn send, void *user) {
    if (!n || !c || !goals || !count || !send || c->tolerance_cm < 0 || !c->hold_ms ||
        !c->pose_timeout_ms || !c->status_timeout_ms || c->echo_timeout_ms != 300 ||
        c->goal_interval_ms < 1000 || !c->max_sends || c->max_sends > 5)
        return 0;
    memset(n, 0, sizeof(*n));
    n->config = *c;
    n->goals = goals;
    n->goal_count = count;
    n->send = send;
    n->user = user;
    n->state = NAV_WAIT_TAKEOFF;
    return 1;
}
/* 保存恢复状态并停止连续条件计时。 */
static void pause_navigation(navigation *n) {
    /* 回显等待中失去必要数据时，恢复后重新发送目标，而非继续等待旧回显。 */
    n->resume_state = n->state == NAV_WAIT_ECHO ? NAV_SEND : n->state;
    n->state = NAV_PAUSED;
    n->holding = 0;
}
void navigation_confirm_height(navigation *n, int valid) {
    n->height_confirmed = valid != 0;
    if (!valid && n->config.require_height_confirmation && n->state != NAV_PAUSED &&
        n->state != NAV_COMPLETE && n->state != NAV_FAILED)
        pause_navigation(n);
}
/* 检查当前位姿是否落在目标水平容差范围内。 */
static int at_goal(const navigation *n, const int16_t pose[6]) {
    /* 到达判定仅比较水平 X/Y，且分别使用厘米容差。 */
    int32_t dx = (int32_t)pose[0] - n->goals[n->goal_index][0];
    int32_t dy = (int32_t)pose[1] - n->goals[n->goal_index][1];
    return dx >= -n->config.tolerance_cm && dx <= n->config.tolerance_cm &&
           dy >= -n->config.tolerance_cm && dy <= n->config.tolerance_cm;
}
/* 检查导航所需数据、飞控状态和可选高度确认。 */
static int ready(const navigation *n, uint32_t now) {
    /* 状态和位姿必须在各自有效期内，且飞行状态允许导航。 */
    return n->have_status && (uint32_t)(now - n->status_ms) < n->config.status_timeout_ms &&
           (n->flight == 3 || n->flight == 4) && n->have_pose &&
           (uint32_t)(now - n->pose_ms) < n->config.pose_timeout_ms &&
           (!n->config.require_height_confirmation || n->height_confirmed);
}
/* 必要数据失效时暂停尚未结束的导航。 */
static void pause_if_needed(navigation *n, uint32_t now) {
    if (n->state == NAV_COMPLETE || n->state == NAV_FAILED || n->state == NAV_PAUSED ||
        ready(n, now))
        return;
    pause_navigation(n);
}
void navigation_accept(navigation *n, const protocol_frame *f, uint32_t now) {
    protocol_status s;
    int16_t values[6];
    pause_if_needed(n, now);
    if (protocol_decode_status(f->bytes, &s)) {
        n->flight = s.flight;
        n->have_status = 1;
        n->status_ms = now;
    } else if (f->bytes[1] == 1 && protocol_decode_data(f->bytes, values)) {
        if ((n->state == NAV_WAIT_TAKEOFF && values[2] <= n->config.takeoff_cm) ||
            (n->state == NAV_WAIT_ARRIVAL && !at_goal(n, values)))
            n->holding = 0;
        memcpy(n->pose, values, sizeof(values));
        n->pose_ms = now;
        n->have_pose = 1;
    } else if (n->state == NAV_WAIT_ECHO && ready(n, now) &&
               (uint32_t)(now - n->sent_ms) < n->config.echo_timeout_ms &&
               memcmp(f->bytes, n->goal_frame, 15) == 0) {
        n->state = NAV_WAIT_ARRIVAL;
        n->holding = 0;
    }
    pause_if_needed(n, now);
}
/* 检查条件是否已连续满足配置的保持时间。 */
static int held(navigation *n, int condition, uint32_t now) {
    /* 条件需连续保持指定时间；中途不满足则重新计时。 */
    if (!condition) {
        n->holding = 0;
        return 0;
    }
    if (!n->holding) {
        n->holding = 1;
        n->hold_ms = now;
        return 0;
    }
    return (uint32_t)(now - n->hold_ms) >= n->config.hold_ms;
}
void navigation_poll(navigation *n, uint32_t now) {

    /* 依次处理暂停恢复、起飞、回显超时、到达判定和目标发送。 */
    pause_if_needed(n, now);
    if (n->state == NAV_PAUSED) {
        if (!ready(n, now))
            return;
        n->state = n->resume_state;
    }
    if (n->state == NAV_WAIT_TAKEOFF && held(n, n->pose[2] > n->config.takeoff_cm, now)) {
        n->holding = 0;
        n->state = NAV_SEND;
    }
    if (n->state == NAV_WAIT_ECHO && (uint32_t)(now - n->sent_ms) >= n->config.echo_timeout_ms) {
        n->state = n->sends >= n->config.max_sends ? NAV_FAILED : NAV_SEND;
    }
    if (n->state == NAV_WAIT_ARRIVAL) {
        if (held(n, at_goal(n, n->pose), now)) {
            n->holding = 0;
            ++n->goal_index;
            n->sends = 0;
            n->state = n->goal_index == n->goal_count ? NAV_COMPLETE : NAV_SEND;
        }
    }
    if (n->state == NAV_SEND &&
        ((n->sends && (uint32_t)(now - n->sent_ms) >= n->config.echo_timeout_ms) ||
         (!n->sends &&
          (!n->have_sent || (uint32_t)(now - n->last_goal_ms) >= n->config.goal_interval_ms)))) {
        if (n->sends >= n->config.max_sends) {
            n->state = NAV_FAILED;
            return;
        }
        protocol_encode_data(n->goal_frame, 2, n->goals[n->goal_index]);
        n->sent_ms = now;
        n->last_goal_ms = now;
        n->have_sent = 1;
        ++n->sends;
        n->state = NAV_WAIT_ECHO;
        n->send(n->user, n->goal_frame);
    }
}
