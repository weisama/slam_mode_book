#ifndef STM32_V3_COMMAND_EXAMPLE_H
#define STM32_V3_COMMAND_EXAMPLE_H
#include "protocol.h"

/* 同步发送完整帧，成功返回非零；user 是调用方上下文。 */
typedef int (*example_transmit_fn)(void *user, const uint8_t frame[15]);
/* 超时时区分完全无响应和只收到部分参数或回显。 */
typedef enum {
    EXAMPLE_IDLE,
    EXAMPLE_WAITING,
    EXAMPLE_ECHO_RECEIVED,
    EXAMPLE_PARAMETERS_RECEIVED,
    EXAMPLE_NO_RESPONSE,
    EXAMPLE_INCOMPLETE
} example_result;
typedef struct {
    /* 接收流解析器和当前请求状态。 */
    protocol_parser parser;
    protocol_request request;
    /* 发送回调及其上下文。 */
    example_transmit_fn transmit;
    void *user;
} command_example;

/* 初始化命令示例及接收解析器。 */
void command_example_init(command_example *example, example_transmit_fn transmit, void *user);
/* 发送命令并开始等待响应；忙、参数无效或发送失败时返回 0。 */
int command_example_start(command_example *example, uint8_t command, uint32_t now_ms,
                          uint32_t timeout_ms);
/* 发送单个参数写入帧；等待其他请求时拒绝发送。 */
int command_example_write_parameter(command_example *example, uint8_t id, int16_t value);
/* 按接收时刻检查超时并将字节流送入解析器。 */
void command_example_receive(command_example *example, const uint8_t *bytes, size_t length,
                             uint32_t now_ms);
/* 检查超时，并区分完整响应、部分响应和无响应。 */
example_result command_example_poll(command_example *example, uint32_t now_ms);
#endif
