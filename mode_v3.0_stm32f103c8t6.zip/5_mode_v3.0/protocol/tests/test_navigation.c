#include "navigation.h"
#include <assert.h>
#include <string.h>
static navigation n; static protocol_parser parser; static uint32_t clock_ms;
static unsigned sends, received; static uint8_t sent[15];
static const int16_t goals[2][6] = {{100,200,100,0,0,0},{300,400,100,0,0,0}};
static void transmit(void *user, const uint8_t *frame) { (void)user; ++sends; memcpy(sent, frame, 15); }
static void receive(void *user, const protocol_frame *frame) { (void)user; ++received; navigation_accept(&n, frame, clock_ms); }
static void feed(const uint8_t *frame, uint32_t t) { clock_ms=t; protocol_parser_feed(&parser,frame,15); }
static void status(uint8_t flight, uint32_t t) { uint8_t f[15]={0xaa,5,0,0,0,0,0,0,0,0,0,0,0,0,0x0a}; f[2]=flight; feed(f,t); }
static void pose(int16_t x,int16_t y,int16_t z,uint32_t t) { uint8_t f[15]; int16_t v[6]={x,y,z,0,0,0}; protocol_encode_data(f,1,v); feed(f,t); }
static void tick(uint32_t t) { navigation_poll(&n,t); }
static void setup(int two_d) { navigation_config c=navigation_defaults(); c.require_height_confirmation=(uint8_t)two_d; sends=received=0; assert(navigation_init(&n,&c,goals,2,transmit,0)); protocol_parser_init(&parser,receive,0); }
static void fresh(uint32_t t) { status(3,t); pose(0,0,51,t); tick(t); }
static void start(void) { fresh(0); fresh(400); fresh(800); fresh(1000); assert(sends==1 && n.state==NAV_WAIT_ECHO); }
static void echo(uint32_t t) { uint8_t f[15]; memcpy(f,sent,15); feed(f,t); }
static void test_mission(void) {
    uint8_t wrong[15]; setup(0); status(3,0); pose(0,0,50,0); tick(0); pose(0,0,51,100); tick(100); fresh(500); pose(0,0,50,700); tick(700); fresh(800); fresh(1200); fresh(1600); fresh(1800); assert(sends==1);
    memcpy(wrong,sent,15); wrong[3]++; feed(wrong,1801); assert(n.state==NAV_WAIT_ECHO); echo(1802); assert(n.state==NAV_WAIT_ARRIVAL);
    pose(120,180,51,1802); tick(1802); pose(121,200,51,2000); tick(2000); pose(120,180,51,2100); tick(2100); pose(120,180,51,2500); tick(2500); status(4,2800); pose(120,180,51,2900); tick(2900); pose(120,180,51,3100); tick(3100); assert(sends==2 && n.goal_index==1);
    echo(3101); pose(300,400,51,3101); tick(3101); pose(300,400,51,3500); tick(3500); pose(300,400,51,3900); tick(3900); pose(300,400,51,4101); tick(4101); assert(n.state==NAV_COMPLETE && sends==2);
}
static void test_pause_and_retry(void) {
    unsigned i; setup(0); start();
    for(i=0;i<3;i++) { status((uint8_t)i,1100+i); tick(1100+i); assert(n.state==NAV_PAUSED && n.goal_index==0); }
    status(3,1200); pose(0,0,51,1200); tick(1200); assert(sends==1); tick(1300); assert(sends==2);
    tick(1700); assert(n.state==NAV_PAUSED); echo(1701); assert(n.state==NAV_PAUSED);
    status(4,1800); pose(0,0,51,1800); tick(1800); assert(sends==3);
    status(4,2100); pose(0,0,51,2100); tick(2100); assert(sends==4);
    status(4,2400); pose(0,0,51,2400); tick(2400); assert(sends==5);
    status(4,2700); pose(0,0,51,2700); tick(2700); assert(n.state==NAV_FAILED && n.goal_index==0 && sends==5);
    assert(received>10);
}
static void test_height_and_status_timeout(void) {
    setup(1); fresh(0); fresh(400); fresh(800); fresh(1200); assert(!sends && n.state==NAV_PAUSED);
    navigation_confirm_height(&n,1); fresh(1300); fresh(1700); fresh(2100); fresh(2300); assert(sends==1);
    echo(2301); pose(0,0,51,2700); tick(2700); pose(0,0,51,3100); tick(3100); pose(0,0,51,3500); tick(3500); pose(0,0,51,3900); tick(3900); pose(0,0,51,4300); tick(4300); assert(n.state==NAV_PAUSED); status(3,4301); pose(0,0,51,4301); tick(4301); assert(n.state==NAV_WAIT_ARRIVAL && sends==1);
    navigation_confirm_height(&n,0); tick(4302); assert(n.state==NAV_PAUSED);
}
static void test_retry_limits(void) { navigation_config c=navigation_defaults(); c.echo_timeout_ms=299; assert(!navigation_init(&n,&c,goals,2,transmit,0)); c.echo_timeout_ms=300; c.max_sends=6; assert(!navigation_init(&n,&c,goals,2,transmit,0)); }
static void test_goal_pacing(void) {
    navigation_config c=navigation_defaults(); c.hold_ms=100;
    sends=0; assert(navigation_init(&n,&c,goals,2,transmit,0)); protocol_parser_init(&parser,receive,0);
    fresh(0); fresh(100); assert(sends==1); echo(101);
    pose(100,200,51,101); tick(101); pose(100,200,51,201); tick(201); assert(n.goal_index==1 && sends==1);
    pose(100,200,51,600); tick(600); assert(sends==1);
    pose(100,200,51,1100); status(3,1100); tick(1100); assert(sends==2);
}
int main(void) { test_mission(); test_pause_and_retry(); test_height_and_status_timeout(); test_goal_pacing(); test_retry_limits(); return 0; }
