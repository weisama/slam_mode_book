﻿#include "protocol.h"
#include <assert.h>
#include <string.h>
static unsigned count;
static protocol_frame last;
static void receive(void *user, const protocol_frame *f) { (void)user; ++count; last=*f; }
static void test_data(void) {
    int16_t values[6] = {-32768, -1, 32767, 0x0aaa, 0, 10}, decoded[6];
    uint8_t frame[15];
    protocol_encode_data(frame, 2, values);
    assert(frame[0]==0xaa && frame[2]==0x80 && frame[3]==0 && frame[14]==0x0a);
    assert(protocol_decode_data(frame, decoded) && memcmp(values, decoded, sizeof(values))==0);
    { protocol_parser p; unsigned before=count; protocol_parser_init(&p,receive,0); protocol_parser_feed(&p,frame,15); assert(count==before+1 && memcmp(last.bytes,frame,15)==0); count=0; }
}
static void test_stream(void) {
    protocol_parser p; uint8_t f[15], bad[15], noise[]={1,2,3}; int16_t v[6]={0x0aaa,-1,0,0,0,0}; unsigned i;
    protocol_parser_init(&p,receive,0); protocol_encode_data(f,3,v);
    protocol_parser_feed(&p,noise,sizeof(noise));
    for(i=0;i<15;++i) protocol_parser_feed(&p,f+i,1);
    assert(count==1 && memcmp(last.bytes,f,15)==0);
    memset(bad,0,15); bad[0]=0xaa; bad[1]=3; bad[14]=0; protocol_parser_feed(&p,bad,15);
    protocol_parser_feed(&p,f,15); assert(count==2 && memcmp(last.bytes,f,15)==0);
    for(i=0;i<100;++i) { f[1]=3; protocol_parser_feed(&p,f,15); f[1]=4; protocol_parser_feed(&p,f,15); if(i%10==0) { f[1]=1; protocol_parser_feed(&p,f,15); } if(i==0) { f[1]=5; protocol_parser_feed(&p,f,15); } }
    assert(count==213);
}
static void test_status(void) {
    uint8_t f[15]={0xaa,5,4,3,3,0xff,100,0,0,0,0,0,0,0,0x0a}; protocol_status s;
    assert(protocol_decode_status(f,&s)); assert(s.flight==4 && s.relocalization==3 && s.planning==3 && s.cpu==0xff && s.memory==100);
}
static void test_requests(void) {
    protocol_request r; protocol_frame f; unsigned i; uint8_t commands[]={1,2,3,4,6};
    const uint8_t expected_ids[]={0,1,2,3,4,5,6,0x11,0x12,0x13,0x14,0x15,0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,0x99};
    assert(memcmp(expected_ids,protocol_param_ids,sizeof(expected_ids))==0);
    assert(!protocol_encode_command(f.bytes,5));
    for(i=0;i<sizeof(commands);++i) { unsigned j; assert(protocol_encode_command(f.bytes,commands[i])); assert(f.bytes[0]==0xaa && f.bytes[1]==0 && f.bytes[2]==commands[i] && f.bytes[14]==0x0a); for(j=3;j<14;++j) assert(f.bytes[j]==0); }
    assert(!protocol_encode_parameter(f.bytes,0xff,1));
    assert(protocol_request_start(&r,3,0,100));
    for(i=0;i<PROTOCOL_PARAM_COUNT;++i) { assert(protocol_encode_parameter(f.bytes,protocol_param_ids[i],(int16_t)(-100-(int)i))); protocol_request_accept(&r,&f); }
    assert(r.result==PROTOCOL_COMPLETE && r.parameters[14]==-114);
    assert(protocol_request_start(&r,3,0,100)); protocol_encode_parameter(f.bytes,0x23,-32768); protocol_request_accept(&r,&f); assert(protocol_request_poll(&r,100)==PROTOCOL_TIMEOUT && r.received_mask && r.parameters[14]==-32768);
    assert(protocol_request_start(&r,4,0,100));
    for(i=0;i<PROTOCOL_PARAM_COUNT;++i) { protocol_encode_parameter(f.bytes,protocol_param_ids[i],(int16_t)i); protocol_request_accept(&r,&f); }
    assert(r.result==PROTOCOL_WAITING); protocol_encode_command(f.bytes,4); protocol_request_accept(&r,&f); assert(r.result==PROTOCOL_COMPLETE);
    assert(protocol_request_start(&r,2,0xfffffff0u,32)); assert(protocol_request_poll(&r,0x10)==PROTOCOL_TIMEOUT);
    assert(protocol_request_start(&r,6,0,100)); protocol_encode_command(f.bytes,6); protocol_request_accept(&r,&f); assert(r.result==PROTOCOL_COMPLETE);
    assert(protocol_request_start(&r,1,0,100)); protocol_encode_command(f.bytes,1); protocol_request_accept(&r,&f); assert(r.result==PROTOCOL_COMPLETE);
}
int main(void) { test_data(); test_stream(); test_status(); test_requests(); return 0; }




