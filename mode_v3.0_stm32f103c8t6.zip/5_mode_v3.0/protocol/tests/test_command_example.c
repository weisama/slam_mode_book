#include "command_example.h"
#include <assert.h>
#include <string.h>
static uint8_t sent[15];
static unsigned sends;
static int transmit(void *user, const uint8_t frame[15]) {
    (void)user; memcpy(sent, frame, 15); ++sends; return 1;
}
static void parameters(command_example *example, unsigned count) {
    unsigned i;
    uint8_t frame[15];
    for (i = 0; i < count; ++i) {
        assert(protocol_encode_parameter(frame, protocol_param_ids[i], (int16_t)(100 + i)));
        command_example_receive(example, frame, 15, 5);
    }
}
int main(void) {
    command_example example;
    command_example_init(&example, transmit, 0);
    assert(sends == 0);
    assert(command_example_start(&example, 1, 0, 100));
    assert(sends == 1 && sent[1] == 0 && sent[2] == 1);
    command_example_receive(&example, sent, 15, 1);
    assert(command_example_poll(&example, 1) == EXAMPLE_ECHO_RECEIVED);

    assert(!command_example_start(&example, 5, 0, 100));
    assert(command_example_start(&example, 3, 0, 100));
    parameters(&example, 22);
    assert(command_example_poll(&example, 5) == EXAMPLE_PARAMETERS_RECEIVED);
    assert(example.request.parameters[14] == 114 && example.request.parameters[21] == 121);

    assert(command_example_start(&example, 3, 0, 100));
    parameters(&example, 21);
    assert(command_example_poll(&example, 100) == EXAMPLE_INCOMPLETE);
    assert(example.request.received_mask == 0x1fffffu);

    assert(command_example_start(&example, 4, 0, 100));
    parameters(&example, 22);
    assert(command_example_poll(&example, 100) == EXAMPLE_INCOMPLETE);
    assert(command_example_start(&example, 4, 0, 100));
    parameters(&example, 22);
    command_example_receive(&example, sent, 15, 6);
    assert(command_example_poll(&example, 6) == EXAMPLE_PARAMETERS_RECEIVED);

    assert(command_example_start(&example, 2, 0, 100));
    sent[3] = 1; /* An altered command frame is not the echo. */
    command_example_receive(&example, sent, 15, 1);
    assert(command_example_poll(&example, 100) == EXAMPLE_NO_RESPONSE);
    assert(command_example_write_parameter(&example, 0x23, 100));
    assert(sent[1] == 0x10 && sent[2] == 0x23 && sent[3] == 0 && sent[4] == 100);
    assert(command_example_poll(&example, 101) == EXAMPLE_NO_RESPONSE);
    assert(!command_example_write_parameter(&example, 0xff, 0));

    assert(command_example_start(&example, 6, 0, 100));
    command_example_receive(&example, sent, 15, 100);
    assert(command_example_poll(&example, 100) == EXAMPLE_NO_RESPONSE);
    assert(command_example_start(&example, 6, 200, 100));
    command_example_receive(&example, sent, 15, 201);
    assert(command_example_poll(&example, 201) == EXAMPLE_ECHO_RECEIVED);
    return 0;
}
