#ifndef V3_EXAMPLE_H
#define V3_EXAMPLE_H
/* 模式分别为定位接收、小车手动目标和无人机航点。 */
#define EXAMPLE_LOCALIZATION 0
#define EXAMPLE_CAR 1
#define EXAMPLE_DRONE 2
/* 根据模式启动示例；2D/3D 共用，启动时不发送命令。 */
void example_start(int mode);
#endif
