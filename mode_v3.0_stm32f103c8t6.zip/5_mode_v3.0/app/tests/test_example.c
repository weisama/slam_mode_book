#include "app.h"
#include "example.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>

static uint32_t clock_ms;
static unsigned sends;
static uint8_t sent[15];
uint32_t board_now_ms(void) { return clock_ms; }
int board_send_frame(const uint8_t frame[15]) {
    memcpy(sent, frame, sizeof sent); ++sends; return 1;
}
extern void app_discard_rx(void);
void board_rx_reset(void) { app_discard_rx(); }
static void receive(const uint8_t frame[15]) {
    unsigned i;
    for (i = 0; i < 15; ++i) app_rx_interrupt(frame[i]);
}
static void fresh(uint32_t at, uint8_t flight) {
    uint8_t frame[15];
    int16_t pose[6] = {0, 0, 100, 0, 0, 0};
    uint8_t status[15] = {0xaa,5,0,0,0,0,0,0,0,0,0,0,0,0,0x0a};
    clock_ms = at; status[2] = flight;
    receive(status); protocol_encode_data(frame, 1, pose); receive(frame);
    app_poll(at);
}
int main(int argc, char **argv) {
    int mode = argc > 1 ? atoi(argv[1]) : EXAMPLE_DRONE;
    app_init(); example_start(mode);
    assert(sends == 0); /* No automatic commands or parameter-discovery dependency. */
    fresh(0, 1); fresh(400, 1); fresh(800, 1); fresh(1000, 1);
    assert(sends == 0); /* Fresh pose alone cannot start a mission while disarmed. */
    app_confirm_height(0); /* The generic example has no mandatory manual height gate. */
    fresh(1100, 3); fresh(1500, 3); fresh(1900, 3); fresh(2100, 3);
    if (mode == EXAMPLE_DRONE) {
        assert(sends == 1 && sent[1] == 2);
        assert(app_navigation.state == NAV_WAIT_ECHO);
        clock_ms = 2101; receive(sent); app_poll(clock_ms);
        assert(app_navigation.state == NAV_WAIT_ARRIVAL);
        clock_ms = 2600; app_poll(clock_ms);
        assert(app_navigation.state == NAV_PAUSED); /* Pose freshness still applies. */
    } else {
        assert(sends == 0);
    }
    return 0;
}
