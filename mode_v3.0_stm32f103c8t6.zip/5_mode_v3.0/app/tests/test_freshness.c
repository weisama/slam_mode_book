#include "app.h"
#include <assert.h>
static uint32_t receive_time;
static unsigned sends;
uint32_t board_now_ms(void) { return receive_time; }
int board_send_frame(const uint8_t frame[15]) { (void)frame; ++sends; return 1; }
extern void app_discard_rx(void);
void board_rx_reset(void) { app_discard_rx(); }
static void receive(const uint8_t frame[15], uint32_t at) {
    unsigned i; receive_time = at;
    for (i = 0; i < 15; ++i) app_rx_interrupt(frame[i]);
}
int main(void) {
    static const int16_t goals[][6] = {{100, 0, 100, 0, 0, 0}};
    int16_t pose[6] = {0, 0, 100, 0, 0, 0};
    uint8_t p[15], status[15] = {0xaa,5,3,0,0,0,0,0,0,0,0,0,0,0,0x0a};
    app_init(); assert(app_start_drone(goals, 1, 0));
    protocol_encode_data(p, 1, pose);
    receive(status, 0); receive(p, 0); app_poll(2501);
    assert(app_navigation.state == NAV_PAUSED && sends == 0);
    receive(status, 2600); receive(p, 2600); app_poll(2600);
    assert(app_navigation.state != NAV_FAILED && sends == 0);
    receive(p, 3000); app_poll(3000);
    receive(p, 3400); app_poll(3400);
    receive(p, 3600); app_poll(3600);
    assert(sends == 1);
    return 0;
}
