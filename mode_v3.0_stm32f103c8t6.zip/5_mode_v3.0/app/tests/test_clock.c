#include "app.h"
#include <assert.h>
static uint32_t clock_ms;
static unsigned sends;
uint32_t board_now_ms(void) { return clock_ms; }
int board_send_frame(const uint8_t frame[15]) { (void)frame; ++sends; return 1; }
extern void app_discard_rx(void);
void board_rx_reset(void) { app_discard_rx(); }
static void feed(const uint8_t frame[15]) { unsigned i; for (i=0; i<15; ++i) app_rx_interrupt(frame[i]); }
int main(void) {
    static const int16_t goals[][6] = {{100,0,100,0,0,0}};
    int16_t pose[6] = {0,0,100,0,0,0};
    uint8_t p[15], status[15] = {0xaa,5,3,0,0,0,0,0,0,0,0,0,0,0,0x0a};
    app_init(); assert(app_start_drone(goals, 1, 0)); protocol_encode_data(p, 1, pose);
    clock_ms=0xfffffc00u; feed(status); feed(p); app_poll(clock_ms);
    clock_ms+=400; feed(p); app_poll(clock_ms);
    clock_ms+=400; feed(p); app_poll(clock_ms);
    clock_ms+=200; feed(p); app_poll(clock_ms);
    assert(sends == 1);
    return 0;
}
