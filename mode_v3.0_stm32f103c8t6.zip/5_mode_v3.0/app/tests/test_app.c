#include "app.h"
#include <assert.h>
#include <string.h>
static unsigned sends;
static uint32_t receive_time;
uint32_t board_now_ms(void) { return receive_time; }
static uint8_t sent[15];
extern void app_discard_rx(void);
void board_rx_reset(void) { app_discard_rx(); }
int board_send_frame(const uint8_t frame[15]) { memcpy(sent, frame, 15); ++sends; return 1; }
static void receive(const uint8_t frame[15]) {
    unsigned i;
    for (i = 0; i < 15; ++i) app_rx_interrupt(frame[i]);
}
int main(void) {
    int16_t pose[6] = {-100, 20, 51, 0, 0, -4};
    int16_t goal[6] = {100, 200, 0, 0, 0, 45};
    uint8_t frame[15];
    unsigned i;
    app_init();
    protocol_encode_data(frame, 1, pose);
    receive(frame); app_poll(10);
    assert(memcmp(pose, app_pose, sizeof pose) == 0);
    assert(app_send_goal(goal, 10));
    assert(sends == 1 && sent[1] == 2);
    assert(!app_send_goal(goal, 1009));
    assert(app_send_goal(goal, 1010));
    receive(sent); app_poll(1010);
    assert(memcmp(goal, app_goal_echo, sizeof goal) == 0);
    for (i = 0; i < 600; ++i) app_rx_interrupt(0xff);
    assert(app_rx_overflows != 0);
    app_poll(1020); pose[0] = 17; protocol_encode_data(frame, 1, pose); receive(frame); app_poll(1021);
    assert(memcmp(pose, app_pose, sizeof pose) == 0);
    return 0;
}
