#ifndef V3_APP_H
#define V3_APP_H
#include "protocol.h"
#include "navigation.h"
#include "command_example.h"

/* 接收字节及错误处理由板级中断调用，其余接口在前台调用。 */
/* 接收缓存由 app_poll 在收到完整帧后更新，始终保留最后一次值。
 * 上电初值为 0；这些缓存本身没有“已收到”或超时标志，0 不代表已经收到数据。 */

/* 0x01 当前位姿，base_init_map 坐标系：
 * [0..2] X/Y/Z（cm），[3..5] Roll/Pitch/Yaw（度）。 */
extern int16_t app_pose[6];
/* 0x03 规划位置指令：[0..2] X/Y/Z（cm），[3..5] Roll/Pitch/Yaw（度）。 */
extern int16_t app_position_command[6];
/* 0x04 规划速度：[0..2] vx/vy/vz（cm/s），[3..4] 固定补零，
 * [5] 偏航角速度（度/s）；[3..4] 不代表实测角速度为零。 */
extern int16_t app_velocity[6];
/* 0x02 接收的目标回显：[0..2] X/Y/Z（cm），[3..5] Roll/Pitch/Yaw（度）。
 * 这是接收缓存，并非本机发送缓存；回显仅表示模块收到帧，不表示已规划或到达。 */
extern int16_t app_goal_echo[6];
/* 0x05 最近的飞控、重定位、规划及资源状态；字段解释见 protocol_status。 */
extern protocol_status app_status;
/* 无人机导航运行状态及命令/参数请求结果。 */
extern navigation app_navigation;
extern command_example app_commands;
/* 接收队列溢出或串口接收错误的累计次数。 */
extern volatile uint32_t app_rx_overflows;
/* 初始化应用的帧解析器和命令处理器。 */
void app_init(void);
/* 中断中缓存一个接收字节及其到达时刻。 */
void app_rx_interrupt(uint8_t byte);
/* 标记串口接收错误，交由前台丢弃缓存并重新同步。 */
void app_rx_error(void);
/* 前台消费接收队列并推进命令和导航状态机，now 为毫秒时刻。 */
void app_poll(uint32_t now);
/* 发送手动目标；goal 的六个字段与 app_goal_echo 相同。
 * 返回 1 仅表示本机发送成功；回显到达后才更新 app_goal_echo。 */
int app_send_goal(const int16_t goal[6], uint32_t now);
/* 可选的人工高度确认，与模块使用的雷达类型无关。 */
int app_start_drone(const int16_t (*goals)[6], size_t count, int require_height_confirmation);
/* 设置或撤销无人机导航的人工高度确认。 */
void app_confirm_height(int valid);
/* 由板级实现；发送函数必须同步发送完整帧，成功返回非零。 */
int board_send_frame(const uint8_t frame[15]);
/* 板级单调毫秒时钟，中断和前台使用同一时基。 */
uint32_t board_now_ms(void);
#endif
