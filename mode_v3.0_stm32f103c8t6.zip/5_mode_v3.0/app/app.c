#include "app.h"
#include <string.h>
#define RX_SIZE 512u
/* 单生产者、单消费者环形缓冲区：中断写入，前台轮询读取。 */
static volatile uint8_t rx[RX_SIZE];
/* 每个队列槽位的接收时刻，以及写入和读取位置。 */
static volatile uint32_t rx_time[RX_SIZE];
static volatile uint16_t rx_head, rx_tail;
/* 丢字节标志和累计丢失事件数。 */
static volatile uint8_t rx_lost;
volatile uint32_t app_rx_overflows;
/* 应用帧解析器；当前帧时间和最近手动目标时间。 */
static protocol_parser parser;
static uint32_t current_ms, last_goal_ms;
/* 是否发过手动目标，以及无人机导航是否已启用。 */
static uint8_t have_goal, drone_active;
int16_t app_pose[6], app_position_command[6], app_velocity[6], app_goal_echo[6];
protocol_status app_status;
navigation app_navigation;
command_example app_commands;
/* 将命令发送请求转交板级串口驱动。 */
static int transmit(void *user, const uint8_t frame[15]) {
    (void)user;
    return board_send_frame(frame);
}
/* 导航回调不返回发送结果，后续通过回显及超时判断。 */
static void navigation_transmit(void *user, const uint8_t frame[15]) {
    (void)user;
    (void)board_send_frame(frame);
}
/* 分发完整帧并刷新对外可见的数据。 */
static void received(void *user, const protocol_frame *frame) {
    (void)user;
    /* 按帧类型更新最近一次数据，再将帧交给无人机导航状态机。 */
    switch (frame->bytes[1]) {
    case 1:
        (void)protocol_decode_data(frame->bytes, app_pose);
        break;
    case 2:
        (void)protocol_decode_data(frame->bytes, app_goal_echo);
        break;
    case 3:
        (void)protocol_decode_data(frame->bytes, app_position_command);
        break;
    case 4:
        (void)protocol_decode_data(frame->bytes, app_velocity);
        break;
    case 5:
        (void)protocol_decode_status(frame->bytes, &app_status);
        break;
    default:
        break;
    }
    if (drone_active)
        navigation_accept(&app_navigation, frame, current_ms);
}
void app_init(void) {
    protocol_parser_init(&parser, received, 0);
    command_example_init(&app_commands, transmit, 0);
}
void app_rx_error(void) {
    rx_lost = 1;
    ++app_rx_overflows;
}
void app_rx_interrupt(uint8_t byte) {
    uint16_t next = (uint16_t)((rx_head + 1u) % RX_SIZE);
    if (next == rx_tail) {
        rx_lost = 1;
        ++app_rx_overflows;
        return;
    }
    /* 保存字节到达时间，防止前台处理延迟掩盖数据过期或回显超时。 */
    rx[rx_head] = byte;
    rx_time[rx_head] = board_now_ms();
    rx_head = next;
}
/* Board disables interrupts while discarding an overflowed buffer. */
extern void board_rx_reset(void);
void app_poll(uint32_t now) {
    if (rx_lost) {
        /* 丢字节后丢弃未处理数据，并重置两个解析器以重新同步帧边界。 */
        board_rx_reset();
        protocol_parser_init(&parser, received, 0);
        protocol_parser_init(&app_commands.parser, app_commands.parser.receive,
                             app_commands.parser.user);
    }
    while (!rx_lost && rx_tail != rx_head) {
        uint8_t byte = rx[rx_tail];
        current_ms = rx_time[rx_tail];
        if ((int32_t)(now - current_ms) < 0)
            now = current_ms;
        rx_tail = (uint16_t)((rx_tail + 1u) % RX_SIZE);
        protocol_parser_feed(&parser, &byte, 1);
        command_example_receive(&app_commands, &byte, 1, current_ms);
    }
    {
        uint32_t end_ms = board_now_ms();
        if ((int32_t)(end_ms - now) > 0)
            now = end_ms;
    }
    (void)command_example_poll(&app_commands, now);
    if (drone_active)
        navigation_poll(&app_navigation, now);
}
/* 由板级在关闭接收中断期间调用，清空队列和丢失标志。 */
void app_discard_rx(void) {
    rx_tail = rx_head;
    rx_lost = 0;
}
int app_send_goal(const int16_t goal[6], uint32_t now) {
    uint8_t frame[15];
    /* 手动目标与无人机导航互斥，手动发送间隔至少 1 秒。 */
    if (drone_active || (have_goal && (uint32_t)(now - last_goal_ms) < 1000u))
        return 0;
    protocol_encode_data(frame, 2, goal);
    if (!board_send_frame(frame))
        return 0;
    have_goal = 1;
    last_goal_ms = now;
    return 1;
}
int app_start_drone(const int16_t (*goals)[6], size_t count, int require_height_confirmation) {
    navigation_config config = navigation_defaults();
    if (have_goal || drone_active)
        return 0;
    config.require_height_confirmation = (uint8_t)(require_height_confirmation != 0);
    drone_active =
        (uint8_t)navigation_init(&app_navigation, &config, goals, count, navigation_transmit, 0);
    return drone_active;
}
void app_confirm_height(int valid) {
    if (drone_active)
        navigation_confirm_height(&app_navigation, valid);
}
