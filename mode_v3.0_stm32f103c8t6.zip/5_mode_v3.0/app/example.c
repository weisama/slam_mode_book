#include "example.h"
#include "app.h"
/* base_init_map 坐标系：X/Y/Z 单位为厘米，roll/pitch/yaw 单位为度。 */
static const int16_t waypoints[][6] = {
    {400, 0, 100, 0, 0, 0}, {400, -200, 100, 0, 0, 0}, {0, 0, 100, 0, 0, 0}};
/* 无人机模式启动航点状态机；其他模式由前台自行读取或发送。 */
void example_start(int mode) {
    if (mode == EXAMPLE_DRONE)
        (void)app_start_drone(waypoints, sizeof(waypoints) / sizeof(waypoints[0]), 0);
}
