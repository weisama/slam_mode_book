#include "main.h"
#include "usart.h"
#include "gpio.h"
#include "app.h"
#include "example.h"
/* Select EXAMPLE_DRONE explicitly to start a drone mission. */
#define SELECTED_EXAMPLE EXAMPLE_CAR
void SystemClock_Config(void);

uint32_t board_now_ms(void) { return HAL_GetTick(); }
extern void app_discard_rx(void);
void board_rx_reset(void) { uint32_t mask = __get_PRIMASK(); __disable_irq(); app_discard_rx(); if (!mask) __enable_irq(); }
int board_send_frame(const uint8_t frame[15]) {
    unsigned i;
    for (i = 0; i < 15; ++i) { while (!(USART1->SR & USART_SR_TXE)) {} USART1->DR = frame[i]; }
    return 1;
}

int main(void) {
    HAL_Init(); SystemClock_Config(); MX_GPIO_Init(); MX_USART1_UART_Init();
    app_init(); example_start(SELECTED_EXAMPLE); __HAL_UART_ENABLE_IT(&huart1, UART_IT_RXNE);
    for (;;) app_poll(HAL_GetTick());
}
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}


void Error_Handler(void) { __disable_irq(); for (;;) {} }
